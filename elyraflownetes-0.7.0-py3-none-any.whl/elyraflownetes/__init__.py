from sqlalchemy import create_engine, text
import pandas as pd
import base64
import datetime
from cryptography.fernet import Fernet
import json
import io
import sys
import requests
import os
from minio import Minio
import datetime


def determine_environment_we_run_in(be_loud=False,list_env=False,environment=""):
    """Functionality to determine if code is executed interactively, or via airflow
    
    Parameters:
    be_loud (bool): indicates if diagnostic information is to be posted via a webokk into slack:/Arctic Risk/#random
    list_env (bool): determines if the diagnostic information should be extended with a list of all environment variables and their values
    environment (str): an optional override, allowed values are "elyra" for interactive/dev environment executions, or "airflow" for prod executions.
    
    Returns:
    str: The environment determined (or overridden)
    
    Comments:
    The base functionality is via the prescence of a Dockerfile defined environment variable THIS_IS_ELYRAFLOW in the worker pod image used (currently
    klausgpaul/elyraflow)
    
    Constraints:
    webhook "import bot" on slack channel #random in team "Arctic Risk"
    """
    if environment in ["elyra","airflow"]:
        #return environment
        pass
    else:
        try:
            ef = os.environ["THIS_IS_ELYRAFLOW"]
            environment = "airflow"
        except:
            environment = "elyra"

    # post to slack #random channel
    info = {"datetime_date":str(datetime.datetime.now()),
            "acticity":"tinker dev prod",
            "environment":environment}
    if list_env:
        for k in sorted(os.environ.keys()):
            info[k] = os.environ[k]
    headers = {'Content-type':'application/json'}
    payload = {"text":json.dumps(info,indent=2)}
    if be_loud:
        r = requests.post("https://hooks.slack.com/services/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",
                          headers=headers,json=payload)
    return environment

def get_current_namespace(environment=""):
    """Determine namespace to be consulted
    
    Parameters:
    environment (str): an optional override, allowed values are "elyra" for interactive/dev environment executions, or "airflow" for prod executions.
    
    Returns:
    str: "develop" for interactive Elyra executions, or "production" for airflow executions
    
    Comments:
    This functionality detemines which namespace is to be consulted to access secrets, which is functionality required to access the postgres
    develop/production databases
    
    """
    # obsolete code which is kept as this is the way to really determine the namespace
    #with open("/var/run/secrets/kubernetes.io/serviceaccount/namespace","rt") as namespace_file:
    #    return namespace_file.read().strip()
    
    # actual code, we use environment:=="elyra" to set "develop", else we use "production"
    if determine_environment_we_run_in(environment=environment) == "elyra":
        return "develop"
    else:
        return "production"
    
    
def set_airflow_config():
    """ Set key environment variables to enable using the python airflow libraries to get connections
    
    Parameters:
    
    Returns:
    True
    
    Comments:
    Initially, the plan was to use airflow hooks to get the credentials and server coordinates for connections configured in the airflow UI.
    It turned out, though, that the airflow wrappers for the various databases are really very thin and, in the case of minio, inconvenient
    (airflow would use boto, not minio, which offers little benefit but adds a lot of overhead in configuring the connection).
    
    We still use airflow's connections to manage the credentials for storage, currently only minio. Airflow stores these data, as encrypted entries,
    in its connection table. The sensitive data are encrypted using a secret Fernet key, which is set in the kubernetes airflow configuration.
    
    To remain compatible with a potential future use of airflow connections, we store the two elements required, AIRFLOW__CORE__FERNET_KEY and 
    AIRFLOW__CORE__SQL_ALCHEMY_CONN, in the os environment.
    
    Important notes:
    * The airflow database is in the development postgres cluster.
    * This function is called in this code block to initialise these settings
    
    Constraints:
    kubernetes secret develop:arcticrisk.arcticrisk-postgres-cluster.credentials.postgresql.acid.zalan.do must exist, accessible, and must
    contain a dict with keys password and username which are valid credentials for the postgres develop cluster
    
    The airflow postgres machine MUST be called "arcticrisk-postgres-cluster"
    """
    from kubernetes import client, config
    config.load_incluster_config()
    v1 = client.CoreV1Api()
    #secret = v1.read_namespaced_secret("airflow-fernet-key",get_current_namespace())
    secret = v1.read_namespaced_secret("airflow-fernet-key","develop")
    os.environ["AIRFLOW__CORE__FERNET_KEY"] = base64.b64decode(secret.data["key"]).decode("ascii")

    #if len(db_server) <= 0:
    #    db_server = os.environ["ARCTICRISK_POSTGRES_CLUSTER_SERVICE_HOST"]#.replace("tcp://","")
    db_server = "arcticrisk-postgres-cluster"
    #secret = v1.read_namespaced_secret("arcticrisk.arcticrisk-postgres-cluster.credentials.postgresql.acid.zalan.do",
    #                                   get_current_namespace())
    secret = v1.read_namespaced_secret("arcticrisk.arcticrisk-postgres-cluster.credentials.postgresql.acid.zalan.do",
                                       "develop")
    password = base64.b64decode(secret.data["password"]).decode("ascii")
    username = base64.b64decode(secret.data["username"]).decode("ascii")

    os.environ["AIRFLOW__CORE__SQL_ALCHEMY_CONN"] = f"postgresql://{username}:{password}@{db_server}/airflow"
    return True

# IMPORTANT, seed configuration
#set_airflow_config()

def decrypt_airflow_entry(entry):
    """Helper function (not used anymore) to decrypt airflow secrets
    
    Parameters:
    entry (str): encrypted string
    
    Returns:
    str: decrypted string
    
    Constraints:
    kubernetes secret develop:airflow-fernet-key must exist, accessible, and must
    contain a dict with key key which contains the Fernet key of the airflow installation
    """
    from kubernetes import client, config
    config.load_incluster_config()
    v1 = client.CoreV1Api()
    #secret = v1.read_namespaced_secret("airflow-fernet-key",get_current_namespace())
    secret = v1.read_namespaced_secret("airflow-fernet-key","develop") # we need to force this to develop
    f = Fernet(base64.b64decode(secret.data["key"]))#.decode("ascii"))
    return f.decrypt(entry)


def get_arctic_airflow_connection(key):
    """Retrieve and decrypt machine coordinates and credentials for airflow connection
    
    Parameters:
    key(str): Airflow Conn Id as configured via the web UI
    
    Returns:
    dict: Dictionary with fully decrypted dict_keys(['conn_id', 'conn_type', 'host', 'login', 
            'password', 'port', 'extra', 'is_encrypted', 'is_extra_encrypted', 'description'])
            
    Comments:
    This function mimics part of the airflow hook functionality in that it determines the connection details and credentials of web UI
    defined connections (mainly used for minio).
    As a (yet to be validated) functionality, keys following the pattern ${<name>} are tried to be resolved as environment variable values
    of variable <name>.
    
    Constraints:
    set_airflow_config() must have been executed prior to call this function
    """
    import re
    conn = create_engine(os.environ["AIRFLOW__CORE__SQL_ALCHEMY_CONN"])
    dfResult = pd.read_sql(f"SELECT * FROM connection WHERE conn_id='{key}'",con=conn)
    retval = {}
    for c in dfResult.columns:
        v = dfResult[c].values[0]
        #print(f"{c}:{v}")
        if c == "id":
            pass
        elif type(v) != str:
            retval[c] = v
        elif not v:
            pass
        elif v[0] == "$":
            p = re.compile("\$\{(.+)\}")
            try:
                environment_variable = p.findall(v)[0]
                retval[c] = os.environ[environment_variable]
            except:
                pass
        elif c in ["password"]:
            f = Fernet(os.environ["AIRFLOW__CORE__FERNET_KEY"])
            retval[c] = f.decrypt(bytes(v.encode("ascii"))).decode("ascii")
        elif c in ["extra"]:
            p = re.compile("\$\{(.+)\}")
            f = Fernet(os.environ["AIRFLOW__CORE__FERNET_KEY"])
            extra = json.loads(f.decrypt(bytes(v.encode("ascii"))).decode("ascii"))
            for k,v in extra.items():
                if v[0] == "$":
                    try:
                        environment_variable = p.findall(v)[0]
                        extra[k] = os.environ[environment_variable]
                    except:
                        pass
            retval[c] = extra
        else:
            retval[c] = v
    return retval


def get_minio_connection(key,environment=""):
    """Get minio handler for configured connection key-namespace
    
    Parameters:
    key (str): name of the connection minus -develop or -production element
    environment (str): environment code is executed in, one of "elyra" or "airflow"
    
    Returns:
    class(Minio): a minio handler
    
    Constraints:
    airflow Connections <key>-develop and/or <key>-production must exist 
    """
    namespace = get_current_namespace(environment=environment)
    info = get_arctic_airflow_connection(f"{key}-{namespace}")
    client = Minio(info["host"], info["login"], info["password"])
    #print(info)
    
    return client

def list_minio_buckets(client):
    """ Convenience function to return list of all minio buckets visible to the client handle
    
    Parameters:
    client (class(Minio)): minio handler
    
    Returns:
    list: list of buckets visible
    """
    names = []
    for b in client.list_buckets():
        names.append(b.name)
    return names

def list_minio_files(client,bucket,prefix="",recursive=False, start_after=None, include_user_meta=False, include_version=False):
    """ Convenience function to return list of all files inside a minio bucket
    
    Parameters:
    client (class(Minio)): minio handler
    bucket (str): bucket name
    prefix (str): optional folder name such as "nsidc/"
    
    Returns:
    list: list of files
    
    """
    files = []
    for c in client.list_objects(bucket,prefix=prefix,recursive=recursive, start_after=start_after, include_user_meta=include_user_meta, include_version=include_version):
        files.append(c.object_name)
    return files

def put_minio_string_to_file(client,bucket,name,data):
    """ Helper function to store a string buffer in a file on a minio bucket
    
    Parameters:
    client (class(Minio)): minio handler
    bucket (str): bucket name
    name (str): full path of file object to be created
    data (str): string data to be uploaded
    
    Returns:
    class(minio.ObjectWriteResult) a dictionary containing the result
    
    Comments:
    This is a helper function that wraps the computation of the string/buffer length. To create such a buffer from a pandas dataframe, use
    
    buffer_string = io.StringIO()
    df.to_csv(buffer_string,index=False)
    
    Note that put_object could also accept metadata, version info, and a retention policy, see 
    https://docs.min.io/docs/python-client-api-reference.html#put_object
    """
    DATA = io.BytesIO(bytes(data.encode("ascii")))
    DATA.seek(0,os.SEEK_END)
    length = DATA.tell()
    print(length)
    DATA.seek(0)
    result = client.put_object(bucket, name, DATA, length)
    return result

def put_minio_inmemory_file_to_file(client,bucket,name,in_memory_file):
    """ Helper function to store a binary buffer in a file on a minio bucket
    
    Parameters:
    client (class(Minio)): minio handler
    bucket (str): bucket name
    name (str): full path of file object to be created
    data (bytes): bytes data to be uploaded
    
    Returns:
    class(minio.ObjectWriteResult) a dictionary containing the result
    
    Comments:
    This is a helper function that wraps the computation of the buffer length. To create such a buffer from a pandas dataframe, use
    
    buffer_binary = io.BytesIO()
    df.to_excel(buffer_binary,index=False)
    
    Note that put_object could also accept metadata, version info, and a retention policy, see 
    https://docs.min.io/docs/python-client-api-reference.html#put_object
    """
    in_memory_file.seek(0,os.SEEK_END)
    length = in_memory_file.tell()
    print(length)
    in_memory_file.seek(0)
    result = client.put_object(bucket, name, in_memory_file, length)
    return result

def get_minio_text_file(client,bucket,name):
    """ Helper function to store a binary buffer in a file on a minio bucket
    
    Parameters:
    client (class(Minio)): minio handler
    bucket (str): bucket name
    name (str): full path of file object to be created
    
    Returns:
    str: string buffer with the content of the file
    
    Comments:
    This is a helper function that wraps the decoding of the otherwises binary result. Some error handling is done, but, for
    UTF-16 encoded files or similar, it is suggested to read these files as binary files using get_minio_binary_file, then 
    decode them using the appropriate codec, without using get_minio_text_file
    """
    r = client.get_object(bucket,name)
    return r.data.decode(errors="replace")

def get_minio_binary_file(client,bucket,name):
    """ Helper function to store a binary buffer in a file on a minio bucket
    
    Parameters:
    client (class(Minio)): minio handler
    bucket (str): bucket name
    name (str): full path of file object to be created
    
    Returns:
    bytes: binary buffer with the content of the file
    
    Comments:
    Convenience function to have a similar API as get_minio_text_file for binary files 
    """
    r = client.get_object(bucket,name)
    return r.data

def get_arcticdata_connection(schema="arcticdata",environment=""):
    """ Get SQLalchemy connection handle to dev/prod data store
    
    Parameters:
    schema (str): optional db schema to connect to
    environment (str): optional overrdide for compute environment, one of "elyra" or "airflow"
    
    Returns:
    class(sqlalchemy.engine.base.Engine): sqlalchemy database connection

    Constraints:
    kubernetes secret [develop|production]:arcticrisk.arcticrisk-postgres-cluster.credentials.postgresql.acid.zalan.do must exist, accessible, and must
    contain a dict with keys password and username which are valid credentials for the postgres develop, or production cluster
    
    The postgres machines MUST be called "arcticrisk-postgres-cluster" for develop and "production-arcticrisk-postgres-cluster" for production
    """
    from kubernetes import client, config

    if environment == "":
        environment = determine_environment_we_run_in()

    if environment == "elyra":
        #db_server = os.environ["ARCTICRISK_POSTGRES_CLUSTER_SERVICE_HOST"]#.replace("tcp://","")
        db_server = "arcticrisk-postgres-cluster"
    else:
        db_server = "production-arcticrisk-postgres-cluster"

    config.load_incluster_config()
    v1 = client.CoreV1Api()
    secret = v1.read_namespaced_secret("arcticrisk.arcticrisk-postgres-cluster.credentials.postgresql.acid.zalan.do",
                                       get_current_namespace(environment=environment))
    password = base64.b64decode(secret.data["password"]).decode("ascii")
    username = base64.b64decode(secret.data["username"]).decode("ascii")
    conn = create_engine(f"postgresql://{username}:{password}@{db_server}/{schema}")
    return conn


def catalogue_jsonld(table,jsonld,schema="arcticdata",environment=""):
    """ Adds a copy of a JSON-LD dict to the t_catalogue_jsonld_records table

    Parameters:
    table(str): name of the data table the JDON-LD record belongs to
    jsonld(dict): dictionary containing JSON-LD description of the data
    schema (str): optional db schema to connect to
    environment (str): optional overrdide for compute environment, one of "elyra" or "airflow"

    Returns:
    True

    Comments:
    JSON-LD records belong to data tables, but one data table/JSON-LD record may be used by multiple charts
    """
    from sqlalchemy import text

    if environment == "":
        environment = determine_environment_we_run_in()

    conn = get_arcticdata_connection(schema=schema,environment=environment)

    conn.execute("CREATE TABLE IF NOT EXISTS t_catalogue_jsonld_records (table_name VARCHAR(100), json_ld JSON)")
    conn.execute(text("COMMENT ON TABLE t_catalogue_jsonld_records IS 'mapping of JSON-LD records to data tables';").execution_options(autocommit=True))
    conn.execute(text("COMMENT ON COLUMN t_catalogue_jsonld_records.table_name IS 'data table name';").execution_options(autocommit=True))
    conn.execute(text("COMMENT ON COLUMN t_catalogue_jsonld_records.json_ld IS 'corresponding JSON-LD record';").execution_options(autocommit=True))

    sql_pre = f"DELETE FROM t_catalogue_jsonld_records WHERE table_name='{table}'"
    try:
        conn.execute(sql_pre)
    except:
        pass

    sql = "INSERT INTO t_catalogue_jsonld_records (table_name,json_ld) VALUES ('{}','{}')".format(table,json.dumps(jsonld))
    conn.execute(sql)


def catalogue_echart(table,echart_path,echart_info,schema="arcticdata",environment=""):
    """ Adds a copy of a JSON-LD dict to the t_catalogue_jsonld_records table

    Parameters:
    table(str): name of the data table the JDON-LD record belongs to
    echart_path(str): full path name of echart json file in bucket
    echart_info(dict): dictionary containing description of the chart for RSS, fields are ['title', 'link', 'description', 'author', 'creator', 'categories', 'comments', 'pubDate']
    schema (str): optional db schema to connect to
    environment (str): optional overrdide for compute environment, one of "elyra" or "airflow"

    Returns:
    True

    Comments:
    This can be used to overwrite the RSS content that would else be taken from JSON-LD
    """
    from sqlalchemy import text

    if environment == "":
        environment = determine_environment_we_run_in()

    conn = get_arcticdata_connection(schema=schema,environment=environment)

    conn.execute("CREATE TABLE IF NOT EXISTS t_catalogue_echart_json_records (table_name VARCHAR(100), echart_path VARCHAR(200), echart_info JSON)")
    conn.execute(text("COMMENT ON TABLE t_catalogue_echart_json_records IS 'mapping of JSON-LD records to data tables';").execution_options(autocommit=True))
    conn.execute(text("COMMENT ON COLUMN t_catalogue_echart_json_records.table_name IS 'data table name';").execution_options(autocommit=True))
    conn.execute(text("COMMENT ON COLUMN t_catalogue_echart_json_records.echart_path IS 'full path name of echart json file in bucket';").execution_options(autocommit=True))
    conn.execute(text("COMMENT ON COLUMN t_catalogue_echart_json_records.echart_info IS 'dictionary containing description of the chart for RSS';").execution_options(autocommit=True))

    sql_pre = f"DELETE FROM t_catalogue_echart_json_records WHERE table_name='{table}'"
    try:
        conn.execute(sql_pre)
    except:
        pass

    sql = "INSERT INTO t_catalogue_echart_json_records (table_name,echart_path,echart_info) VALUES ('{}','{}','{}')".format(table,echart_path,json.dumps(echart_info))
    conn.execute(sql)


def catalogue_csv(table,csv_path,schema="arcticdata",environment=""):
    """ Adds a copy of a JSON-LD dict to the t_catalogue_jsonld_records table

    Parameters:
    table(str): name of the data table the csv is based upon
    csv_path(str): full path name of csv file in bucket
    schema (str): optional db schema to connect to
    environment (str): optional overrdide for compute environment, one of "elyra" or "airflow"

    Returns:
    True

    Comments:
    ---
    """
    from sqlalchemy import text
    
    if environment == "":
        environment = determine_environment_we_run_in()

    conn = get_arcticdata_connection(schema=schema,environment=environment)

    conn.execute("CREATE TABLE IF NOT EXISTS t_catalogue_csv_records (table_name VARCHAR(100), csv_path VARCHAR(200))")
    conn.execute(text("COMMENT ON TABLE t_catalogue_csv_records IS 'mapping of JSON-LD records to data tables';").execution_options(autocommit=True))
    conn.execute(text("COMMENT ON COLUMN t_catalogue_csv_records.table_name IS 'data table name';").execution_options(autocommit=True))
    conn.execute(text("COMMENT ON COLUMN t_catalogue_csv_records.csv_path IS 'full path name of csv file in bucket';").execution_options(autocommit=True))

    sql_pre = f"DELETE FROM t_catalogue_csv_records WHERE table_name='{table}'"
    try:
        conn.execute(sql_pre)
    except:
        pass

    sql = "INSERT INTO t_catalogue_csv_records (table_name,csv_path) VALUES ('{}','{}')".format(table,csv_path)
    conn.execute(sql)
